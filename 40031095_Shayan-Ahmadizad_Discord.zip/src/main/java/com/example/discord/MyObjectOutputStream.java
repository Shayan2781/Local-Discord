package com.example.discord;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.*;


class MyObjectOutputStream extends ObjectOutputStream {

    MyObjectOutputStream() throws IOException
    {
        super();
    }

    MyObjectOutputStream(OutputStream o) throws IOException
    {
        super(o);
    }
    public void writeStreamHeader() throws IOException
    {
        return;
    }
}
